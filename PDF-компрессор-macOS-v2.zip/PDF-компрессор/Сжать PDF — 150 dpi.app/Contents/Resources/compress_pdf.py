#!/usr/bin/env python3
import argparse
import sys
from pathlib import Path

try:
    import fitz
except ImportError:
    print("Не найден PyMuPDF. Выполните в Терминале:\npython3 -m pip install --user PyMuPDF", file=sys.stderr)
    raise SystemExit(2)


def size_text(value):
    size = float(value)
    for unit in ("Б", "КБ", "МБ", "ГБ"):
        if size < 1024 or unit == "ГБ":
            return f"{size:.1f} {unit}" if unit != "Б" else f"{int(size)} {unit}"
        size /= 1024


def destination_for(source, dpi):
    result = source.with_name(f"{source.stem}_{dpi}dpi.pdf")
    counter = 2
    while result.exists():
        result = source.with_name(f"{source.stem}_{dpi}dpi_{counter}.pdf")
        counter += 1
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dpi", type=int, choices=(96, 150), required=True)
    parser.add_argument("files", nargs="+")
    args = parser.parse_args()
    quality = 82 if args.dpi == 150 else 75
    messages = []
    for name in args.files:
        source = Path(name).resolve()
        if not source.is_file() or source.suffix.lower() != ".pdf":
            raise RuntimeError(f"Это не PDF-файл: {source.name}")
        destination = destination_for(source, args.dpi)
        document = fitz.open(source)
        if document.needs_pass:
            document.close()
            raise RuntimeError(f"Файл защищён паролем: {source.name}")
        document.rewrite_images(
            dpi_threshold=args.dpi + 15,
            dpi_target=args.dpi,
            quality=quality,
            lossy=True,
            lossless=True,
            bitonal=False,
            color=True,
            gray=True,
        )
        document.save(destination, garbage=4, deflate=True, clean=True)
        document.close()
        before, after = source.stat().st_size, destination.stat().st_size
        messages.append(f"{source.name}\n{size_text(before)} → {size_text(after)}")
    print("\n\n".join(messages))


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print(f"Ошибка: {error}", file=sys.stderr)
        raise SystemExit(1)
